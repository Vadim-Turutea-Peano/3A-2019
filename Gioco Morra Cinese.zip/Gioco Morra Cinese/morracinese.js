alert("Ciao, sei pronto a iniziare?");

var nomeGiocatore = window.prompt("Bene, per prima cosa inserisci il tuo nome: ");

document.getElementById("titolo").innerHTML = "Benvenuto " + nomeGiocatore;

var sceltaUtente;

function cliccatoCarta() {
	sceltaUtente = "carta";
	alert(nomeGiocatore + " hai scelto " + sceltaUtente); 
}

function cliccatoForbici() {
	sceltaUtente = "forbici";
	alert(nomeGiocatore + " hai scelto " + sceltaUtente); 
}

function cliccatoSasso() {
	sceltaUtente = "sasso";
	alert(nomeGiocatore + " hai scelto " + sceltaUtente); 
}

function verdetto() {
	document.getElementById("carta").style.display = 'none';
	document.getElementById("forbici").style.display = 'none';
	document.getElementById("sasso").style.display = 'none';
	document.getElementById("pulsante").style.display = 'none';
	var sceltaComputer;
	if(sceltaUtente == "carta"){
		sceltaComputer = "forbici";
}
	if(sceltaUtente == "forbici"){
		sceltaComputer = "sasso";
}
    if(sceltaUtente == "sasso"){
		sceltaComputer = "carta";
}
document.getElementById("titolo").innerHTML = nomeGiocatore + " hai perso, mi dispiace ):";
document.getElementById("informazioni").innerHTML = "Il computer ha scelto " + sceltaComputer + ". Tu, invece, hai scelto " + sceltaUtente;
}